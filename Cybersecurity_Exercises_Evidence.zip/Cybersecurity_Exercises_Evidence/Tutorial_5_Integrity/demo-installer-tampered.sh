#!/bin/bash
echo Demo installer integrity test
echo Harmless lab script
# modified
